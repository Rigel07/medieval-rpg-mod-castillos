# Castillos Flotantes (Forge 1.20.1)

Enormes **islas flotantes** (radio hasta ~135 bloques) con un **castillo medieval** y un **pueblo**,
protegidas por una **barrera** que bloquea a los mobs hostiles y **regenera** a quien esté dentro.

## Qué hay en cada isla
- **Isla**: relieve con colinas, lagos, árboles (roble, abedul, cerezo), flores, caminos y una base rocosa
  con minerales. Hay una isla por cada 1000x1000 bloques con ~60% de probabilidad, a 150-205 de altura.
- **Castillo**: muralla con adarve y almenas, 4 torres con escalera de mano y tejado cónico, puerta con puente,
  torreón de 4 plantas (gran salón con trono, dormitorios, biblioteca, tesoro con 7 cofres de botín de
  vainilla), patio con pozo, jardín, establo y zona de entrenamiento.
- **Pueblo**: calles, plaza con pozo y farolas, casas de entramado (tejados de ladrillo/abeto/roble oscuro),
  herrería, panadería, taberna, capilla, 2 puestos de mercado, 2 granjas con cultivos y 3 corrales.
- **Habitantes**: aldeanos medievales propios (campesino, granjero, herrero, panadero, guardia real, noble)
  y criaturas pacíficas de TODOS los mods instalados (cualquier entidad de categoría CREATURE).
- **Barrera**: nada hostil puede aparecer ni cruzarla (los que entren son expulsados con chispas y sonido).
  Todo ser amistoso dentro recibe Regeneración continua. Se ve como chispas en el borde.

## Aldeanos medievales
Clic derecho: te saludan. Con una **esmeralda**: te dan algo según su oficio (6 tratos al día).
Los guardias llevan espada y escudo y defienden la isla de los hostiles que lleguen a su alcance.

## Compilar en GitHub
Sube el .zip (o su contenido) con `.github/workflows/build.yml` -> Actions -> el .jar sale en Releases/Artifacts.

## Ajustes
`world/Islands.java`: tamaño, frecuencia (CHANCE, CELL), altura, distancia castillo-pueblo.
`barrier/Barrier.java`: radio y altura de la barrera. `barrier/BarrierEvents.java`: comportamiento.
`world/Population.java`: qué criaturas pueblan las islas.

## Biomas
Las islas se añaden a todos los biomas de vanilla del Overworld (`data/castillos_flotantes/forge/biome_modifier/add_islands.json`).
Para biomas de otros mods, añade sus ids a la lista `biomes` de ese archivo (NO crees un segundo modificador con la misma feature: duplicarla en un bioma provoca el error "Feature order cycle found").
