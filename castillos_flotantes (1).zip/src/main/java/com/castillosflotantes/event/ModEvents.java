package com.castillosflotantes.event;

import com.castillosflotantes.CastillosFlotantesMod;
import com.castillosflotantes.entity.AldeanoEntity;
import com.castillosflotantes.entity.ModEntities;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = CastillosFlotantesMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD)
public class ModEvents {
    @SubscribeEvent
    public static void attributes(EntityAttributeCreationEvent event) {
        event.put(ModEntities.ALDEANO.get(), AldeanoEntity.createAttributes().build());
    }
}
