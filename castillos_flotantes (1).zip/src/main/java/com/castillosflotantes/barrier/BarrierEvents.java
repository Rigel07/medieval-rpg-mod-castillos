package com.castillosflotantes.barrier;

import com.castillosflotantes.CastillosFlotantesMod;
import com.castillosflotantes.world.Islands;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.EntityJoinLevelEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * La barrera: ningun mob hostil puede entrar (se cancela su aparicion y se expulsan los que cruzan),
 * y todo ser amistoso dentro recibe Regeneracion de forma continua. Se ve como chispas en el borde.
 */
@Mod.EventBusSubscriber(modid = CastillosFlotantesMod.MOD_ID)
public class BarrierEvents {

    private static boolean isHostile(Entity e) {
        return e instanceof Enemy || e.getType().getCategory() == MobCategory.MONSTER;
    }

    @SubscribeEvent
    public static void onLevelTick(TickEvent.LevelTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        if (!(event.level instanceof ServerLevel level)) return;
        if (level.dimension() != Level.OVERWORLD) return;
        long time = level.getGameTime();
        if (time % 5 != 0) return;
        List<ServerPlayer> players = level.players();
        if (players.isEmpty()) return;
        long seed = level.getSeed();
        Set<Long> done = new HashSet<>();
        for (ServerPlayer p : players) {
            for (Islands.Island isl : Islands.near(seed, p.getBlockX(), p.getBlockZ(), Barrier.RADIUS + 120)) {
                if (done.add(isl.seed)) processIsland(level, isl, time);
                shimmer(level, p, isl);
            }
        }
    }

    private static void processIsland(ServerLevel level, Islands.Island isl, long time) {
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, Barrier.bounds(isl))) {
            if (!e.isAlive() || e.isSpectator()) continue;
            if (!Barrier.inside(isl, e.position())) continue;
            if (isHostile(e)) {
                repel(level, isl, e);
            } else if (time % 20 == 0 && (e instanceof Player || e instanceof Mob)) {
                e.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 60, 0, true, false, true));
            }
        }
    }

    /** Saca al hostil por la salida mas cercana. */
    private static void repel(ServerLevel level, Islands.Island isl, LivingEntity e) {
        Vec3 p = e.position();
        double dx = p.x - isl.cx, dz = p.z - isl.cz;
        double r = Math.hypot(dx, dz);
        double dRad = Barrier.RADIUS - r;
        double dDown = p.y - Barrier.bottomY(isl);
        double dome = Barrier.domeY(isl, r);
        double dTop = dome - p.y;
        double nx = p.x, ny = p.y, nz = p.z;
        if (dDown <= dRad && dDown <= dTop) {
            ny = Barrier.bottomY(isl) - 3;
        } else if (dTop <= dRad) {
            ny = dome + 3;
        } else {
            if (r < 0.001) { dx = 1; dz = 0; r = 1; }
            double s = (Barrier.RADIUS + 3) / r;
            nx = isl.cx + dx * s;
            nz = isl.cz + dz * s;
        }
        level.sendParticles(ParticleTypes.ELECTRIC_SPARK, p.x, p.y + e.getBbHeight() / 2, p.z, 20, 0.4, 0.6, 0.4, 0.2);
        level.playSound(null, p.x, p.y, p.z, SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.HOSTILE, 1.5F, 0.8F);
        e.teleportTo(nx, ny, nz);
        e.setDeltaMovement(Vec3.ZERO);
        if (e instanceof Mob m) {
            m.getNavigation().stop();
            m.setTarget(null);
        }
    }

    /** Chispas sobre la superficie de la barrera cerca del jugador (para que se vea). */
    private static void shimmer(ServerLevel level, ServerPlayer p, Islands.Island isl) {
        double f = Barrier.f(isl, p.getX(), p.getY(), p.getZ());
        double distApprox = Math.abs(Math.sqrt(f) - 1.0) * Barrier.RADIUS;
        if (distApprox > 40) return;
        for (int k = 0; k < 8; k++) {
            double qx = p.getX() + (level.random.nextDouble() - 0.5) * 36;
            double qy = p.getY() + (level.random.nextDouble() - 0.5) * 24;
            double qz = p.getZ() + (level.random.nextDouble() - 0.5) * 36;
            double dx = qx - isl.cx, dz = qz - isl.cz;
            double top = Barrier.topY(isl);
            double dyA = Math.max(0.0, qy - top);
            double ff = (dx * dx + dz * dz) / ((double) Barrier.RADIUS * Barrier.RADIUS)
                    + (dyA * dyA) / ((double) Barrier.HEIGHT * Barrier.HEIGHT);
            if (ff < 1.0E-6) continue;
            double s = 1.0 / Math.sqrt(ff);
            double sx = isl.cx + dx * s, sz = isl.cz + dz * s;
            double sy = qy <= top ? qy : top + dyA * s;
            if (sy < Barrier.bottomY(isl)) continue;
            double ddx = sx - p.getX(), ddy = sy - p.getY(), ddz = sz - p.getZ();
            if (ddx * ddx + ddy * ddy + ddz * ddz > 26 * 26) continue;
            level.sendParticles(p, ParticleTypes.ELECTRIC_SPARK, true, sx, sy, sz, 1, 0, 0, 0, 0);
        }
    }

    /** Los hostiles no pueden aparecer ni cargarse dentro de la barrera. */
    @SubscribeEvent
    public static void onJoin(EntityJoinLevelEvent event) {
        if (!(event.getLevel() instanceof ServerLevel level)) return;
        if (level.dimension() != Level.OVERWORLD) return;
        Entity e = event.getEntity();
        if (!isHostile(e)) return;
        for (Islands.Island isl : Islands.near(level.getSeed(), e.getBlockX(), e.getBlockZ(), 0)) {
            if (Barrier.inside(isl, e.position())) {
                event.setCanceled(true);
                return;
            }
        }
    }
}
