package com.castillosflotantes.barrier;

import com.castillosflotantes.world.Islands;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/** Forma de la barrera: cilindro bajo la isla + cupula encima (semielipsoide). */
public final class Barrier {
    public static final int RADIUS = Islands.RADIUS + 14;
    public static final int HEIGHT = 110;

    public static int topY(Islands.Island i) { return i.y0 + Islands.CASTLE_DY; }
    public static int bottomY(Islands.Island i) { return i.y0 - Islands.MAX_DEPTH - 20; }

    public static AABB bounds(Islands.Island i) {
        return new AABB(i.cx - RADIUS, bottomY(i), i.cz - RADIUS, i.cx + RADIUS, topY(i) + HEIGHT, i.cz + RADIUS);
    }

    /** f <= 1 => dentro de la barrera. */
    public static double f(Islands.Island i, double x, double y, double z) {
        double dx = x - i.cx, dz = z - i.cz;
        double dy = Math.max(0.0, y - topY(i));
        return (dx * dx + dz * dz) / ((double) RADIUS * RADIUS) + (dy * dy) / ((double) HEIGHT * HEIGHT);
    }

    public static boolean inside(Islands.Island i, Vec3 p) {
        return p.y >= bottomY(i) && f(i, p.x, p.y, p.z) <= 1.0;
    }

    public static double domeY(Islands.Island i, double r) {
        double q = r / RADIUS;
        return topY(i) + HEIGHT * Math.sqrt(Math.max(0.0, 1.0 - q * q));
    }
}
