package com.castillosflotantes.client;

import com.castillosflotantes.CastillosFlotantesMod;
import com.castillosflotantes.entity.AldeanoEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.ArmedModel;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.HumanoidArm;

/** Aldeano chibi: cabezon, cuerpecito, sombrero (con ala opcional) y naricilla. */
public class AldeanoModel extends EntityModel<AldeanoEntity> implements ArmedModel {
    public static final ModelLayerLocation LAYER =
            new ModelLayerLocation(new ResourceLocation(CastillosFlotantesMod.MOD_ID, "aldeano"), "main");

    private final ModelPart root, head, hatBrim, body, leftArm, rightArm, leftLeg, rightLeg;

    public AldeanoModel(ModelPart root) {
        this.root = root;
        this.head = root.getChild("head");
        this.hatBrim = this.head.getChild("hat_brim");
        this.body = root.getChild("body");
        this.leftArm = root.getChild("left_arm");
        this.rightArm = root.getChild("right_arm");
        this.leftLeg = root.getChild("left_leg");
        this.rightLeg = root.getChild("right_leg");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition pd = mesh.getRoot();

        PartDefinition head = pd.addOrReplaceChild("head",
                CubeListBuilder.create().texOffs(0, 0).addBox(-4F, -8F, -4F, 8F, 8F, 8F),
                PartPose.offset(0F, 12F, 0F));
        head.addOrReplaceChild("nose",
                CubeListBuilder.create().texOffs(48, 43).addBox(-1F, -3F, -5F, 2F, 3F, 1F), PartPose.ZERO);
        head.addOrReplaceChild("hat_crown",
                CubeListBuilder.create().texOffs(0, 16).addBox(-4.5F, -11F, -4.5F, 9F, 3F, 9F), PartPose.ZERO);
        head.addOrReplaceChild("hat_brim",
                CubeListBuilder.create().texOffs(0, 28).addBox(-7F, -9F, -7F, 14F, 1F, 14F), PartPose.ZERO);

        pd.addOrReplaceChild("body",
                CubeListBuilder.create().texOffs(0, 43).addBox(-3F, 0F, -2F, 6F, 7F, 4F),
                PartPose.offset(0F, 12F, 0F));
        pd.addOrReplaceChild("right_arm",
                CubeListBuilder.create().texOffs(24, 43).addBox(-1F, 0F, -1F, 2F, 6F, 2F),
                PartPose.offset(-4F, 12.5F, 0F));
        pd.addOrReplaceChild("left_arm",
                CubeListBuilder.create().texOffs(32, 43).addBox(-1F, 0F, -1F, 2F, 6F, 2F),
                PartPose.offset(4F, 12.5F, 0F));
        pd.addOrReplaceChild("right_leg",
                CubeListBuilder.create().texOffs(0, 56).addBox(-1.5F, 0F, -1.5F, 3F, 5F, 3F),
                PartPose.offset(-1.6F, 19F, 0F));
        pd.addOrReplaceChild("left_leg",
                CubeListBuilder.create().texOffs(12, 56).addBox(-1.5F, 0F, -1.5F, 3F, 5F, 3F),
                PartPose.offset(1.6F, 19F, 0F));

        return LayerDefinition.create(mesh, 64, 64);
    }

    @Override
    public void setupAnim(AldeanoEntity e, float limbSwing, float limbSwingAmount, float ageInTicks,
                          float netHeadYaw, float headPitch) {
        this.hatBrim.visible = e.hasBrim();
        this.head.yRot = netHeadYaw * Mth.DEG_TO_RAD;
        this.head.xRot = headPitch * Mth.DEG_TO_RAD;

        float swing = limbSwing * 0.6662F;
        this.rightLeg.xRot = Mth.cos(swing) * 1.2F * limbSwingAmount;
        this.leftLeg.xRot = Mth.cos(swing + Mth.PI) * 1.2F * limbSwingAmount;
        this.rightArm.xRot = Mth.cos(swing + Mth.PI) * 0.9F * limbSwingAmount;
        this.leftArm.xRot = Mth.cos(swing) * 0.9F * limbSwingAmount;
        this.rightArm.zRot = 0.05F;
        this.leftArm.zRot = -0.05F;
        this.body.zRot = Mth.sin(swing) * 0.05F * limbSwingAmount; // andar graciosito

        if (e.isWaving()) {
            this.rightArm.xRot = -2.6F;
            this.rightArm.zRot = Mth.sin(ageInTicks * 0.6F) * 0.35F;
        }
        if (e.isAggressive()) {
            this.rightArm.xRot = -1.6F;
            this.leftArm.xRot = -1.6F;
        }
    }

    @Override
    public void translateToHand(HumanoidArm arm, PoseStack poseStack) {
        (arm == HumanoidArm.RIGHT ? this.rightArm : this.leftArm).translateAndRotate(poseStack);
    }

    @Override
    public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer, int packedLight, int packedOverlay,
                               float r, float g, float b, float a) {
        this.root.render(poseStack, buffer, packedLight, packedOverlay, r, g, b, a);
    }
}
