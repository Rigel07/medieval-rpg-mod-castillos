package com.castillosflotantes.client;

import com.castillosflotantes.CastillosFlotantesMod;
import com.castillosflotantes.entity.AldeanoEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.layers.ItemInHandLayer;
import net.minecraft.resources.ResourceLocation;

public class AldeanoRenderer extends MobRenderer<AldeanoEntity, AldeanoModel> {
    private static final ResourceLocation[] TEXTURES = new ResourceLocation[AldeanoEntity.VARIANTS];

    static {
        for (int i = 0; i < TEXTURES.length; i++) {
            TEXTURES[i] = new ResourceLocation(CastillosFlotantesMod.MOD_ID, "textures/entity/aldeano_" + i + ".png");
        }
    }

    public AldeanoRenderer(EntityRendererProvider.Context context) {
        super(context, new AldeanoModel(context.bakeLayer(AldeanoModel.LAYER)), 0.35F);
        this.addLayer(new ItemInHandLayer<>(this, context.getItemInHandRenderer()));
    }

    @Override
    public ResourceLocation getTextureLocation(AldeanoEntity entity) {
        return TEXTURES[entity.getVariant()];
    }

    @Override
    protected void scale(AldeanoEntity entity, PoseStack poseStack, float partialTick) {
        poseStack.scale(0.9F, 0.9F, 0.9F);
    }
}
