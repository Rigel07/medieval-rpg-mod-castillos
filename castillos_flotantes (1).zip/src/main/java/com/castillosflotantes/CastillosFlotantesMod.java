package com.castillosflotantes;

import com.castillosflotantes.entity.ModEntities;
import com.castillosflotantes.item.ModCreativeTabs;
import com.castillosflotantes.item.ModItems;
import com.castillosflotantes.world.ModFeatures;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(CastillosFlotantesMod.MOD_ID)
public class CastillosFlotantesMod {
    public static final String MOD_ID = "castillos_flotantes";

    public CastillosFlotantesMod() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModEntities.ENTITIES.register(bus);
        ModItems.ITEMS.register(bus);
        ModFeatures.FEATURES.register(bus);
        ModCreativeTabs.TABS.register(bus);
    }
}
