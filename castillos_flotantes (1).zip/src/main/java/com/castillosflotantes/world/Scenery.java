package com.castillosflotantes.world;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LeavesBlock;
import net.minecraft.world.level.block.state.BlockState;

/** Caminos, arboles (roble, abedul, cerezo), flores y criaturas sueltas por la isla. */
final class Scenery {

    static void build(IslandCanvas c) {
        Islands.Island isl = c.isl;
        roads(c);
        trees(c);
        plants(c);
        meadowAnimals(c);
    }

    private static boolean suitable(Islands.Island isl, int x, int z) {
        double lx = x - isl.cx, lz = z - isl.cz;
        double r = Math.sqrt(lx * lx + lz * lz);
        if (r > Terrain.edgeRadius(isl, lx, lz) - 5) return false;
        if (Math.max(Math.abs(lx), Math.abs(lz)) <= Islands.CASTLE_HALF + 5) return false;
        if (Math.hypot(x - isl.vx, z - isl.vz) <= Islands.VILLAGE_R + 3) return false;
        return !Terrain.lakeNear(isl, x, z, 3);
    }

    // ------------------------------------------------------------ caminos
    private static BlockState pathState(int x, int z) {
        int r = (int) Math.floorMod(Islands.hash(55, x, z), 100L);
        return r < 70 ? Blocks.DIRT_PATH.defaultBlockState() : r < 85 ? Blocks.COARSE_DIRT.defaultBlockState() : Blocks.GRAVEL.defaultBlockState();
    }

    private static void line(IslandCanvas c, int x1, int z1, int x2, int z2) {
        Islands.Island isl = c.isl;
        int steps = Math.max(Math.abs(x2 - x1), Math.abs(z2 - z1)) * 2;
        for (int i = 0; i <= steps; i++) {
            double t = steps == 0 ? 0 : (double) i / steps;
            int x = (int) Math.round(x1 + (x2 - x1) * t), z = (int) Math.round(z1 + (z2 - z1) * t);
            for (int ox = -1; ox <= 1; ox++) {
                for (int oz = -1; oz <= 1; oz++) {
                    int px = x + ox, pz = z + oz;
                    if (Terrain.lakeNear(isl, px, pz, 0)) continue;
                    int gy = Terrain.groundH(isl, px, pz);
                    if (!c.has(px, gy, pz) && !c.has(px, gy + 1, pz)) c.set(px, gy, pz, pathState(px, pz));
                }
            }
        }
    }

    private static void roads(IslandCanvas c) {
        Islands.Island isl = c.isl;
        int sgn = isl.vx >= isl.cx ? 1 : -1;
        int gx = isl.cx, gz = isl.cz + 37;              // final del puente
        int ax = isl.cx + sgn * 46, az = isl.cz + 40;   // rodea el castillo
        int bz = Math.max(isl.vz, az);
        line(c, gx, gz, ax, az);
        if (isl.vz < az) {
            line(c, ax, az, ax, isl.vz);
            line(c, ax, isl.vz, isl.vx, isl.vz);
        } else {
            line(c, ax, az, isl.vx, isl.vz);
        }
    }

    // ------------------------------------------------------------ arboles
    private static BlockState leaves(Block b) {
        return b.defaultBlockState().setValue(LeavesBlock.PERSISTENT, true);
    }

    private static void tree(IslandCanvas c, int x, int gy, int z, long h) {
        int type = (int) Math.floorMod(h, 100L);
        Block log, leaf;
        int th, rad;
        if (type < 45) { log = Blocks.OAK_LOG; leaf = Blocks.OAK_LEAVES; th = 5 + (int) Math.floorMod(h >>> 8, 2L); rad = 2; }
        else if (type < 70) { log = Blocks.BIRCH_LOG; leaf = Blocks.BIRCH_LEAVES; th = 6 + (int) Math.floorMod(h >>> 8, 2L); rad = 2; }
        else { log = Blocks.CHERRY_LOG; leaf = Blocks.CHERRY_LEAVES; th = 4 + (int) Math.floorMod(h >>> 8, 2L); rad = 3; }
        BlockState logS = log.defaultBlockState();
        BlockState leafS = leaves(leaf);
        for (int i = 1; i <= th; i++) c.set(x, gy + i, z, logS);
        for (int dy = -2; dy <= 1; dy++) {
            int r = dy <= 0 ? rad : rad - 1;
            for (int dx = -r; dx <= r; dx++) {
                for (int dz = -r; dz <= r; dz++) {
                    if (dx == 0 && dz == 0 && dy <= 0) continue;
                    if (Math.abs(dx) == r && Math.abs(dz) == r && Math.floorMod(Islands.hash(h, dx * 7 + dy, dz), 3L) == 0) continue;
                    int py = gy + th + dy;
                    if (!c.has(x + dx, py, z + dz)) c.set(x + dx, py, z + dz, leafS);
                }
            }
        }
    }

    private static void trees(IslandCanvas c) {
        Islands.Island isl = c.isl;
        int step = 6;
        for (int gx = -Islands.RADIUS; gx <= Islands.RADIUS; gx += step) {
            for (int gz = -Islands.RADIUS; gz <= Islands.RADIUS; gz += step) {
                long h = Islands.hash(isl.seed, gx, gz + 777);
                if (Math.floorMod(h, 100L) >= 38) continue;
                int x = isl.cx + gx + (int) Math.floorMod(h >>> 8, (long) step);
                int z = isl.cz + gz + (int) Math.floorMod(h >>> 16, (long) step);
                if (!suitable(isl, x, z)) continue;
                int gy = Terrain.groundH(isl, x, z);
                if (c.has(x, gy, z) || c.has(x, gy + 1, z)) continue;
                tree(c, x, gy, z, h >>> 24);
            }
        }
    }

    // ------------------------------------------------------------ plantas
    private static void plants(IslandCanvas c) {
        Islands.Island isl = c.isl;
        Block[] flowers = {Blocks.POPPY, Blocks.DANDELION, Blocks.CORNFLOWER, Blocks.OXEYE_DAISY, Blocks.AZURE_BLUET, Blocks.ALLIUM};
        for (int x = isl.cx - Islands.RADIUS; x <= isl.cx + Islands.RADIUS; x++) {
            for (int z = isl.cz - Islands.RADIUS; z <= isl.cz + Islands.RADIUS; z++) {
                int r = (int) Math.floorMod(Islands.hash(isl.seed + 5, x, z), 1000L);
                if (r >= 90) continue;
                if (!suitable(isl, x, z)) continue;
                int gy = Terrain.groundH(isl, x, z);
                if (c.has(x, gy, z) || c.has(x, gy + 1, z)) continue;
                Block b = r < 60 ? Blocks.GRASS : flowers[r % flowers.length];
                c.set(x, gy + 1, z, b.defaultBlockState());
            }
        }
    }

    // ------------------------------------------------------------ criaturas sueltas
    private static void meadowAnimals(IslandCanvas c) {
        Islands.Island isl = c.isl;
        int placed = 0;
        for (int k = 0; k < 80 && placed < 14; k++) {
            long h = Islands.hash(isl.seed, 4000 + k, 11);
            double ang = Math.floorMod(h, 3600L) / 3600.0 * Math.PI * 2;
            double dist = 45 + Math.floorMod(h >>> 12, 60L);
            int x = isl.cx + (int) Math.round(Math.cos(ang) * dist);
            int z = isl.cz + (int) Math.round(Math.sin(ang) * dist);
            if (!suitable(isl, x, z)) continue;
            int gy = Terrain.groundH(isl, x, z);
            if (c.has(x, gy + 1, z)) continue;
            c.spot(x, gy + 1, z, IslandCanvas.ANIMAL, 0);
            placed++;
        }
    }
}
