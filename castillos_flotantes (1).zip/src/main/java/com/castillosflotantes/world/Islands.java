package com.castillosflotantes.world;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

/** Posicion y parametros de las islas: una por celda de 1000x1000 bloques con ~60% de probabilidad. */
public final class Islands {
    // ======== AJUSTES ========
    public static final int CELL = 1000;
    public static final double CHANCE = 0.6;
    public static final int RADIUS = 135;        // radio maximo de la isla (MUY grande)
    public static final int MAX_DEPTH = 60;      // profundidad maxima por debajo
    public static final int CASTLE_DY = 6;       // altura de la explanada del castillo sobre y0
    public static final int VILLAGE_DY = 3;      // altura de la explanada del pueblo sobre y0
    public static final int CASTLE_HALF = 36;    // medio lado de la explanada del castillo
    public static final int VILLAGE_R = 38;      // radio de la explanada del pueblo
    public static final int VILLAGE_DIST = 80;   // distancia castillo -> pueblo
    // =========================

    public static final class Island {
        public final long seed;
        public final int cx, cz, y0, vx, vz;
        volatile Terrain.Lake[] lakes;

        Island(long seed, int cx, int cz, int y0, int vx, int vz) {
            this.seed = seed; this.cx = cx; this.cz = cz; this.y0 = y0; this.vx = vx; this.vz = vz;
        }
    }

    private static long mix(long z) {
        z += 0x9E3779B97F4A7C15L;
        z = (z ^ (z >>> 30)) * 0xBF58476D1CE4E5B9L;
        z = (z ^ (z >>> 27)) * 0x94D049BB133111EBL;
        return z ^ (z >>> 31);
    }

    public static long hash(long a, long b, long c) {
        return mix(a ^ mix(b ^ mix(c + 0x632BE59BD9B4E019L)));
    }

    public static Island inCell(long worldSeed, int cellX, int cellZ) {
        long h = hash(worldSeed ^ 0x43A57E1L, cellX, cellZ);
        double roll = ((h >>> 11) & 0xFFFFFFL) / (double) 0x1000000;
        if (roll >= CHANCE) return null;
        int margin = RADIUS + 25;
        int range = CELL - 2 * margin;
        long h2 = mix(h + 1), h3 = mix(h + 2), h4 = mix(h + 3), h5 = mix(h + 4);
        int cx = cellX * CELL + margin + (int) Math.floorMod(h2, (long) range);
        int cz = cellZ * CELL + margin + (int) Math.floorMod(h3, (long) range);
        int y0 = 150 + (int) Math.floorMod(h4, 55L);
        double ang = Math.floorMod(h5, 3600L) / 3600.0 * Math.PI * 2;
        int vx = cx + (int) Math.round(Math.cos(ang) * VILLAGE_DIST);
        int vz = cz + (int) Math.round(Math.sin(ang) * VILLAGE_DIST);
        return new Island(h, cx, cz, y0, vx, vz);
    }

    /** Islas cuyas celdas tocan el cuadrado [x-range, x+range] x [z-range, z+range]. */
    public static List<Island> near(long worldSeed, int x, int z, int range) {
        List<Island> out = new ArrayList<>();
        int minX = Math.floorDiv(x - range, CELL), maxX = Math.floorDiv(x + range, CELL);
        int minZ = Math.floorDiv(z - range, CELL), maxZ = Math.floorDiv(z + range, CELL);
        for (int cx = minX; cx <= maxX; cx++) {
            for (int cz = minZ; cz <= maxZ; cz++) {
                Island i = inCell(worldSeed, cx, cz);
                if (i != null) out.add(i);
            }
        }
        return out;
    }

    private static final ConcurrentHashMap<Long, IslandCanvas> CACHE = new ConcurrentHashMap<>();

    /** Estructuras ya calculadas de la isla (castillo, pueblo, arboles...). Seguro entre hilos. */
    public static IslandCanvas canvas(Island isl) {
        if (CACHE.size() > 6) CACHE.clear();
        return CACHE.computeIfAbsent(isl.seed, k -> IslandCanvas.build(isl));
    }
}
