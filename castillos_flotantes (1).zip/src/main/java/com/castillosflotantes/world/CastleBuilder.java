package com.castillosflotantes.world;

import net.minecraft.core.Direction;
import net.minecraft.world.level.block.BedBlock;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BedPart;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;

import static com.castillosflotantes.world.Build.AIR_STATE;
import static com.castillosflotantes.world.Build.F;
import static com.castillosflotantes.world.Build.S;
import static net.minecraft.world.level.block.Blocks.*;

/** Castillo medieval: muralla con adarve, 4 torres, puerta con puente, torreon de 4 plantas y patio. */
final class CastleBuilder {

    private static BlockState brick(int x, int y, int z) {
        int r = (int) Math.floorMod(Islands.hash(0xB1C, x * 131L + y, z), 16L);
        return r < 11 ? S(STONE_BRICKS) : r < 14 ? S(MOSSY_STONE_BRICKS) : S(CRACKED_STONE_BRICKS);
    }

    static void build(IslandCanvas c) {
        Islands.Island isl = c.isl;
        Build b = new Build(c, isl.cx, isl.cz, Rotation.NONE);
        int gy = isl.y0 + Islands.CASTLE_DY;
        walls(b, gy);
        towers(b, gy);
        gate(b, gy);
        keep(b, gy);
        turrets(b, gy);
        stairs(b, gy);
        hall(b, gy);
        bedrooms(b, gy);
        library(b, gy);
        treasury(b, gy);
        courtyard(b, gy);
    }

    // ------------------------------------------------------------ muralla
    private static void walls(Build b, int gy) {
        for (int x = -26; x <= 26; x++) {
            for (int z = -26; z <= 26; z++) {
                int m = Math.max(Math.abs(x), Math.abs(z));
                if (m < 24) continue;
                for (int y = gy; y <= gy + 11; y++) b.set(x, y, z, brick(x, y, z));
                if (m == 26) {
                    b.set(x, gy + 12, z, brick(x, gy + 12, z));
                    if (((x + z) & 1) == 0) b.set(x, gy + 13, z, brick(x, gy + 13, z));
                    int mn = Math.min(Math.abs(x), Math.abs(z));
                    if (mn <= 22 && Math.floorMod(mn, 6) == 3) {
                        b.set(x, gy + 5, z, AIR_STATE);
                        b.set(x, gy + 6, z, AIR_STATE);
                    }
                }
            }
        }
        // escaleras al adarve (este y oeste)
        for (int side : new int[]{-1, 1}) {
            for (int i = 0; i <= 10; i++) {
                int x = 23 * side, z = 12 - i, y = gy + 1 + i;
                b.set(x, y, z, F(STONE_BRICK_STAIRS, Direction.NORTH));
                for (int yy = gy + 1; yy < y; yy++) b.set(x, yy, z, brick(x, yy, z));
            }
        }
    }

    // ------------------------------------------------------------ torres de las esquinas
    private static void towers(Build b, int gy) {
        BlockState glass = S(LIGHT_BLUE_STAINED_GLASS);
        for (int sx : new int[]{-1, 1}) {
            for (int sz : new int[]{-1, 1}) {
                int tx = 26 * sx, tz = 26 * sz;
                for (int dx = -6; dx <= 6; dx++) {
                    for (int dz = -6; dz <= 6; dz++) {
                        int d2 = dx * dx + dz * dz;
                        if (d2 > 30) continue;
                        boolean wall = d2 > 12;
                        int x = tx + dx, z = tz + dz;
                        for (int y = gy; y <= gy + 21; y++) {
                            int rel = y - gy;
                            BlockState s;
                            if (wall || rel == 0) s = brick(x, y, z);
                            else if (rel == 7 || rel == 14 || rel == 21) s = S(SPRUCE_PLANKS);
                            else s = AIR_STATE;
                            b.set(x, y, z, s);
                        }
                    }
                }
                // escalera de mano
                Direction lf = sx > 0 ? Direction.WEST : Direction.EAST;
                for (int y = gy + 1; y <= gy + 20; y++) b.set(tx + 3 * sx, y, tz, F(LADDER, lf));
                // puerta al patio
                for (int y = gy + 1; y <= gy + 3; y++) {
                    b.set(tx - 5 * sx, y, tz, AIR_STATE);
                    b.set(tx - 4 * sx, y, tz, AIR_STATE);
                }
                // ventanas
                for (int y : new int[]{gy + 4, gy + 5, gy + 11, gy + 12, gy + 18, gy + 19}) {
                    for (int off : new int[]{4, 5}) {
                        b.set(tx, y, tz + off, glass);
                        b.set(tx, y, tz - off, glass);
                    }
                }
                // tejado conico
                for (int k = 0; k <= 8; k++) {
                    double rr = 6.2 - 0.7 * k;
                    rr *= rr;
                    for (int dx = -7; dx <= 7; dx++)
                        for (int dz = -7; dz <= 7; dz++)
                            if (dx * dx + dz * dz <= rr) b.set(tx + dx, gy + 22 + k, tz + dz, S(RED_TERRACOTTA));
                }
                for (int h = 31; h <= 33; h++) b.set(tx, gy + h, tz, S(OAK_FENCE));
                b.set(tx, gy + 34, tz, S(RED_BANNER));
            }
        }
    }

    // ------------------------------------------------------------ puerta y puente
    private static void gate(Build b, int gy) {
        for (int x = -3; x <= 3; x++) {
            for (int z = 24; z <= 26; z++) {
                b.set(x, gy, z, S(DARK_OAK_PLANKS));
                for (int y = gy + 1; y <= gy + 7; y++) b.set(x, y, z, AIR_STATE);
                if (Math.abs(x) <= 2) b.set(x, gy + 8, z, AIR_STATE);
            }
        }
        for (int side : new int[]{-1, 1}) {
            int x0 = side < 0 ? -10 : 6, x1 = side < 0 ? -6 : 10;
            for (int x = x0; x <= x1; x++) {
                for (int z = 27; z <= 30; z++) {
                    for (int y = gy; y <= gy + 17; y++) b.set(x, y, z, brick(x, y, z));
                    if (x == x0 || x == x1 || z == 30) {
                        b.set(x, gy + 18, z, brick(x, gy + 18, z));
                        if (((x + z) & 1) == 0) b.set(x, gy + 19, z, brick(x, gy + 19, z));
                    }
                }
            }
            int cx = (x0 + x1) / 2;
            for (int y = gy + 10; y <= gy + 12; y++) b.set(cx, y, 30, S(LIGHT_BLUE_STAINED_GLASS));
            b.set(cx, gy + 14, 31, F(RED_WALL_BANNER, Direction.SOUTH));
        }
        for (int x = -3; x <= 3; x++)
            for (int z = 27; z <= 36; z++) b.set(x, gy, z, S(DARK_OAK_PLANKS));
        for (int z : new int[]{28, 34})
            for (int sd : new int[]{-4, 4}) Decor.lamp(b, sd, gy, z);
        b.spawn(-4, gy + 1, 31, IslandCanvas.VILLAGER, 4);
        b.spawn(4, gy + 1, 31, IslandCanvas.VILLAGER, 4);
        for (int sd : new int[]{-1, 1}) {
            b.spawn(20 * sd, gy + 12, 22, IslandCanvas.VILLAGER, 4);
            b.spawn(20 * sd, gy + 12, -22, IslandCanvas.VILLAGER, 4);
        }
    }

    // ------------------------------------------------------------ torreon
    private static boolean hole(int x, int z, int idx) {
        if ((idx - 1) % 2 == 0) return x >= -8 && x <= -7 && z >= 1 && z <= 8;
        return x >= 7 && x <= 8 && z >= -8 && z <= -1;
    }

    private static boolean blocked(int f, int x, int z) {
        boolean w = x >= -8 && x <= -7 && z >= 1 && z <= 8;
        boolean e = x >= 7 && x <= 8 && z >= -8 && z <= -1;
        return f == 0 ? w : (w || e);
    }

    private static void keep(Build b, int gy) {
        BlockState glass = S(LIGHT_BLUE_STAINED_GLASS);
        for (int x = -10; x <= 10; x++) {
            for (int z = -10; z <= 10; z++) {
                boolean wall = Math.abs(x) >= 9 || Math.abs(z) >= 9;
                for (int y = gy; y <= gy + 32; y++) {
                    int rel = y - gy;
                    BlockState s;
                    if (wall) s = brick(x, y, z);
                    else if (rel == 0) s = S(SPRUCE_PLANKS);
                    else if (rel % 8 == 0) {
                        if (rel == 32) s = hole(x, z, 4) ? AIR_STATE : S(STONE_BRICKS);
                        else s = hole(x, z, rel / 8) ? AIR_STATE : S(SPRUCE_PLANKS);
                    } else s = AIR_STATE;
                    b.set(x, y, z, s);
                }
                if (Math.max(Math.abs(x), Math.abs(z)) == 10) {
                    b.set(x, gy + 33, z, brick(x, gy + 33, z));
                    if (((x + z) & 1) == 0) b.set(x, gy + 34, z, brick(x, gy + 34, z));
                }
            }
        }
        // ventanas
        for (int fl = 0; fl < 4; fl++) {
            int base = gy + 8 * fl;
            for (int t : new int[]{-6, -2, 2, 6}) {
                for (int w : new int[]{9, 10}) {
                    for (int y = base + 3; y <= base + 4; y++) {
                        if (!(fl == 0 && Math.abs(t) <= 2)) b.set(t, y, w, glass);
                        b.set(t, y, -w, glass);
                        b.set(w, y, t, glass);
                        b.set(-w, y, t, glass);
                    }
                }
            }
        }
        // entrada (arco)
        for (int x = -2; x <= 2; x++)
            for (int z = 9; z <= 10; z++)
                for (int y = gy + 1; y <= gy + 4; y++) b.set(x, y, z, AIR_STATE);
        for (int x = -1; x <= 1; x++)
            for (int z = 9; z <= 10; z++) b.set(x, gy + 5, z, AIR_STATE);
        for (int sd : new int[]{-1, 1}) b.set(4 * sd, gy + 6, 11, F(RED_WALL_BANNER, Direction.SOUTH));
    }

    private static void turrets(Build b, int gy) {
        for (int sx : new int[]{-1, 1}) {
            for (int sz : new int[]{-1, 1}) {
                int tx = 10 * sx, tz = 10 * sz;
                for (int dx = -2; dx <= 2; dx++)
                    for (int dz = -2; dz <= 2; dz++)
                        for (int y = gy; y <= gy + 38; y++) b.set(tx + dx, y, tz + dz, brick(tx + dx, y, tz + dz));
                for (int y : new int[]{gy + 30, gy + 31}) {
                    b.set(tx + 2 * sx, y, tz, S(LIGHT_BLUE_STAINED_GLASS));
                    b.set(tx, y, tz + 2 * sz, S(LIGHT_BLUE_STAINED_GLASS));
                }
                for (int k = 0; k <= 3; k++) {
                    int half = 3 - k;
                    for (int dx = -half; dx <= half; dx++)
                        for (int dz = -half; dz <= half; dz++) b.set(tx + dx, gy + 39 + k, tz + dz, S(RED_TERRACOTTA));
                }
                for (int h = 43; h <= 45; h++) b.set(tx, gy + h, tz, S(OAK_FENCE));
                b.set(tx, gy + 46, tz, S(RED_BANNER));
            }
        }
    }

    private static void stairs(Build b, int gy) {
        for (int L = 0; L < 4; L++) {
            int fy = gy + 8 * L;
            for (int i = 0; i < 8; i++) {
                int y = fy + 1 + i;
                int x = (L % 2 == 0) ? -8 : 8;
                int z = (L % 2 == 0) ? 8 - i : -8 + i;
                Direction d = (L % 2 == 0) ? Direction.NORTH : Direction.SOUTH;
                b.set(x, y, z, F(STONE_BRICK_STAIRS, d));
                for (int yy = fy + 1; yy < y; yy++) b.set(x, yy, z, brick(x, yy, z));
            }
        }
    }

    private static void lanterns(Build b, int y, int f, int[][] spots) {
        for (int[] s : spots) {
            if (Math.abs(s[0]) <= 8 && Math.abs(s[1]) <= 8 && !blocked(f, s[0], s[1])) {
                b.set(s[0], y, s[1], S(LANTERN).setValue(net.minecraft.world.level.block.LanternBlock.HANGING, true));
            }
        }
    }

    // ------------------------------------------------------------ planta baja: gran salon
    private static void hall(Build b, int gy) {
        int y1 = gy + 1;
        for (int z = -5; z <= 8; z++)
            for (int x = -1; x <= 1; x++) b.set(x, y1, z, S(RED_CARPET));
        for (int tx : new int[]{-4, 4}) {
            for (int z = -4; z <= 4; z++) b.set(tx, y1, z, S(SPRUCE_PLANKS));
            b.set(tx, gy + 2, 0, S(CAKE));
            for (int z : new int[]{-3, -1, 1, 3}) {
                b.set(tx > 0 ? 5 : -5, y1, z, F(SPRUCE_STAIRS, tx > 0 ? Direction.EAST : Direction.WEST));
                b.set(tx > 0 ? 3 : -3, y1, z, F(SPRUCE_STAIRS, tx > 0 ? Direction.WEST : Direction.EAST));
            }
        }
        for (int x = -3; x <= 3; x++)
            for (int z = -8; z <= -6; z++) b.set(x, y1, z, S(STONE_BRICK_SLAB));
        b.set(0, y1, -8, F(DARK_OAK_STAIRS, Direction.NORTH));
        b.set(-1, y1, -8, S(DARK_OAK_SLAB));
        b.set(1, y1, -8, S(DARK_OAK_SLAB));
        b.set(-3, gy + 3, -8, F(RED_WALL_BANNER, Direction.SOUTH));
        b.set(3, gy + 3, -8, F(RED_WALL_BANNER, Direction.SOUTH));
        for (int sd : new int[]{-6, 6}) {
            b.set(sd, gy + 3, -8, F(WALL_TORCH, Direction.SOUTH));
            b.set(sd, gy + 3, 8, F(WALL_TORCH, Direction.NORTH));
        }
        lanterns(b, gy + 7, 0, new int[][]{{-4, -4}, {4, -4}, {0, 0}, {-4, 4}, {4, 4}, {0, -6}});
        b.chest(7, y1, -7, Direction.WEST, "minecraft:chests/simple_dungeon");
        b.chest(-6, y1, -7, Direction.EAST, "minecraft:chests/simple_dungeon");
        b.spawn(-2, y1, -4, IslandCanvas.VILLAGER, 5);
        b.spawn(2, y1, -4, IslandCanvas.VILLAGER, 5);
        b.spawn(-6, y1, 6, IslandCanvas.VILLAGER, 4);
        b.spawn(6, y1, 6, IslandCanvas.VILLAGER, 4);
        b.spawn(5, y1, 3, IslandCanvas.VILLAGER, 0);
        b.spawn(-5, y1, -2, IslandCanvas.VILLAGER, 3);
    }

    // ------------------------------------------------------------ planta 1: dormitorios
    private static BlockState bed(Direction d, BedPart part) {
        return F(RED_BED, d).setValue(BedBlock.PART, part);
    }

    private static void bedrooms(Build b, int gy) {
        int base = gy + 8, y1 = base + 1;
        for (int z = -6; z <= 6; z++)
            for (int x = -1; x <= 1; x++) b.set(x, y1, z, S(RED_CARPET));
        for (int x : new int[]{-5, -2, 2, 5}) {
            b.set(x, y1, 7, bed(Direction.NORTH, BedPart.FOOT));
            b.set(x, y1, 6, bed(Direction.NORTH, BedPart.HEAD));
            b.set(x, y1, -7, bed(Direction.SOUTH, BedPart.FOOT));
            b.set(x, y1, -6, bed(Direction.SOUTH, BedPart.HEAD));
        }
        b.chest(-8, y1, -2, Direction.EAST, "minecraft:chests/village/village_plains_house");
        b.chest(8, y1, 3, Direction.WEST, "minecraft:chests/village/village_plains_house");
        lanterns(b, base + 7, 1, new int[][]{{-4, 0}, {4, 0}, {0, -4}, {0, 4}});
        b.spawn(0, y1, 0, IslandCanvas.VILLAGER, 0);
    }

    // ------------------------------------------------------------ planta 2: biblioteca
    private static void library(Build b, int gy) {
        int base = gy + 16, y1 = base + 1;
        for (int h = 0; h <= 2; h++) {
            for (int z = -8; z <= 0; z++) b.set(-8, y1 + h, z, S(BOOKSHELF));
            for (int z = 0; z <= 8; z++) b.set(8, y1 + h, z, S(BOOKSHELF));
            for (int x = -6; x <= 6; x++) b.set(x, y1 + h, -8, S(BOOKSHELF));
        }
        b.set(0, y1, 0, S(ENCHANTING_TABLE));
        b.set(-3, y1, -3, F(LECTERN, Direction.SOUTH));
        b.set(3, y1, -3, F(LECTERN, Direction.SOUTH));
        b.set(3, y1, 3, S(CAULDRON));
        b.set(-3, y1, 3, S(BREWING_STAND));
        b.chest(6, y1, 0, Direction.WEST, "minecraft:chests/stronghold_library");
        lanterns(b, base + 7, 2, new int[][]{{-4, 0}, {4, 0}, {0, -4}, {0, 4}});
        b.spawn(0, y1, 4, IslandCanvas.VILLAGER, 5);
    }

    // ------------------------------------------------------------ planta 3: tesoro
    private static void treasury(Build b, int gy) {
        int base = gy + 24, y1 = base + 1;
        for (int dx = -1; dx <= 1; dx++)
            for (int dz = -1; dz <= 1; dz++) b.set(dx, y1, dz, S(GOLD_BLOCK));
        b.set(0, y1 + 1, 0, S(DIAMOND_BLOCK));
        String[] tables = {"minecraft:chests/woodland_mansion", "minecraft:chests/end_city_treasure",
                "minecraft:chests/bastion_treasure", "minecraft:chests/ancient_city",
                "minecraft:chests/desert_pyramid", "minecraft:chests/jungle_temple"};
        int[][] pos = {{-6, -8}, {-3, -8}, {3, -8}, {6, -8}, {8, 2}, {8, 5}};
        Direction[] face = {Direction.SOUTH, Direction.SOUTH, Direction.SOUTH, Direction.SOUTH, Direction.WEST, Direction.WEST};
        for (int i = 0; i < pos.length; i++) b.chest(pos[i][0], y1, pos[i][1], face[i], tables[i]);
        b.chest(-8, y1, -3, Direction.EAST, "minecraft:chests/stronghold_corridor");
        lanterns(b, base + 7, 3, new int[][]{{-4, 0}, {4, 0}, {0, -4}, {0, 4}});
        b.spawn(-4, y1, 4, IslandCanvas.VILLAGER, 4);
        b.spawn(4, y1, 4, IslandCanvas.VILLAGER, 4);
    }

    // ------------------------------------------------------------ patio
    private static void courtyard(Build b, int gy) {
        for (int z = 11; z <= 23; z++) {
            for (int x = -1; x <= 1; x++) {
                int r = (int) Math.floorMod(Islands.hash(9, x, z), 3L);
                b.set(x, gy, z, r == 0 ? S(STONE_BRICKS) : S(COBBLESTONE));
            }
        }
        Decor.well(b, -14, gy, 14);
        // jardin
        for (int x = -17; x <= -11; x++) {
            for (int z = -17; z <= -11; z++) {
                int r = (int) Math.floorMod(Islands.hash(33, x, z), 10L);
                if (r < 5) b.set(x, gy + 1, z, S(r < 2 ? POPPY : r < 3 ? CORNFLOWER : r < 4 ? OXEYE_DAISY : DANDELION));
            }
        }
        for (int i = 0; i < 3; i++) b.spawn(-16 + i * 2, gy + 1, -14, IslandCanvas.ANIMAL, 0);
        // establo
        for (int x = 10; x <= 18; x++)
            for (int z = 11; z <= 17; z++) b.set(x, gy + 4, z, S(SPRUCE_SLAB));
        for (int px : new int[]{11, 17})
            for (int pz : new int[]{12, 16})
                for (int h = 1; h <= 3; h++) b.set(px, gy + h, pz, S(OAK_FENCE));
        b.set(12, gy + 1, 16, S(HAY_BLOCK));
        b.set(16, gy + 1, 16, S(HAY_BLOCK));
        b.spawn(14, gy + 1, 14, IslandCanvas.ANIMAL, 0);
        b.spawn(15, gy + 1, 14, IslandCanvas.ANIMAL, 0);
        // zona de entrenamiento
        b.set(14, gy + 1, -14, S(HAY_BLOCK));
        b.set(14, gy + 2, -14, S(HAY_BLOCK));
        b.set(14, gy + 3, -14, F(CARVED_PUMPKIN, Direction.SOUTH));
        b.set(16, gy + 1, -12, S(HAY_BLOCK));
        // farolas del camino
        for (int z : new int[]{14, 20})
            for (int sd : new int[]{-3, 3}) Decor.lamp(b, sd, gy, z);
    }
}
