package com.castillosflotantes.world;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;

import static com.castillosflotantes.world.Build.S;

/** Elementos decorativos reutilizables: pozo, farola, puesto de mercado. */
final class Decor {
    static void well(Build b, int cx, int y, int cz) {
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                if (dx == 0 && dz == 0) {
                    b.set(cx, y, cz, S(Blocks.WATER));
                } else {
                    b.set(cx + dx, y, cz + dz, S(Blocks.COBBLESTONE));
                    b.set(cx + dx, y + 1, cz + dz, S(Blocks.COBBLESTONE));
                }
                b.set(cx + dx, y + 4, cz + dz, S(Blocks.SPRUCE_SLAB));
            }
        }
        for (int sx : new int[]{-1, 1}) {
            for (int sz : new int[]{-1, 1}) {
                b.set(cx + sx, y + 2, cz + sz, S(Blocks.OAK_FENCE));
                b.set(cx + sx, y + 3, cz + sz, S(Blocks.OAK_FENCE));
            }
        }
    }

    static void lamp(Build b, int x, int y, int z) {
        b.set(x, y + 1, z, S(Blocks.OAK_FENCE));
        b.set(x, y + 2, z, S(Blocks.OAK_FENCE));
        b.set(x, y + 3, z, S(Blocks.LANTERN));
    }

    static void stall(Build b, int cx, int y, int cz, Block wool1, Block wool2) {
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                b.set(cx + dx, y + 4, cz + dz, S(((dx + dz) & 1) == 0 ? wool1 : wool2));
            }
        }
        for (int sx : new int[]{-1, 1}) {
            for (int sz : new int[]{-1, 1}) {
                for (int h = 1; h <= 3; h++) b.set(cx + sx, y + h, cz + sz, S(Blocks.OAK_FENCE));
            }
        }
        b.set(cx, y + 1, cz - 1, S(Blocks.BARREL));
        b.set(cx - 1, y + 1, cz, S(Blocks.HAY_BLOCK));
        b.set(cx + 1, y + 1, cz, S(Blocks.CRAFTING_TABLE));
    }
}
