package com.castillosflotantes.world;

import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;

/** Constructor en coordenadas locales (con origen y rotacion). Los estados se rotan con BlockState.rotate. */
final class Build {
    static final BlockState AIR_STATE = Blocks.AIR.defaultBlockState();

    final IslandCanvas c;
    final int ox, oz;
    final Rotation rot;

    Build(IslandCanvas c, int ox, int oz, Rotation rot) {
        this.c = c; this.ox = ox; this.oz = oz; this.rot = rot;
    }

    static BlockState S(Block b) { return b.defaultBlockState(); }

    static BlockState F(Block b, Direction d) {
        return b.defaultBlockState().setValue(BlockStateProperties.HORIZONTAL_FACING, d);
    }

    int wx(int lx, int lz) {
        switch (rot) {
            case CLOCKWISE_90: return ox - lz;
            case CLOCKWISE_180: return ox - lx;
            case COUNTERCLOCKWISE_90: return ox + lz;
            default: return ox + lx;
        }
    }

    int wz(int lx, int lz) {
        switch (rot) {
            case CLOCKWISE_90: return oz + lx;
            case CLOCKWISE_180: return oz - lz;
            case COUNTERCLOCKWISE_90: return oz - lx;
            default: return oz + lz;
        }
    }

    void set(int lx, int y, int lz, BlockState s) {
        c.set(wx(lx, lz), y, wz(lx, lz), s.rotate(rot));
    }

    void box(int x1, int y1, int z1, int x2, int y2, int z2, BlockState s) {
        for (int x = Math.min(x1, x2); x <= Math.max(x1, x2); x++)
            for (int y = Math.min(y1, y2); y <= Math.max(y1, y2); y++)
                for (int z = Math.min(z1, z2); z <= Math.max(z1, z2); z++)
                    set(x, y, z, s);
    }

    void chest(int lx, int y, int lz, Direction facing, String table) {
        BlockState s = F(Blocks.CHEST, facing).rotate(rot);
        c.chest(wx(lx, lz), y, wz(lx, lz), s, new ResourceLocation(table));
    }

    void spawn(int lx, int y, int lz, int kind, int variant) {
        c.spot(wx(lx, lz), y, wz(lx, lz), kind, variant);
    }
}
