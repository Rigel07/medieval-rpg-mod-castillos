package com.castillosflotantes.world;

import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.entity.RandomizableContainerBlockEntity;
import net.minecraft.world.level.block.state.BlockState;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Todos los bloques "construidos" de una isla (castillo, pueblo, arboles, caminos...), repartidos por
 * chunk. Se calcula una vez y despues cada chunk coloca su parte. Inmutable tras construirse.
 */
public final class IslandCanvas {
    public static final int ANIMAL = 0;
    public static final int VILLAGER = 1;

    public static final class Spot {
        final int x, y, z, kind, variant;
        Spot(int x, int y, int z, int kind, int variant) { this.x = x; this.y = y; this.z = z; this.kind = kind; this.variant = variant; }
    }

    public final Islands.Island isl;
    private final Map<Long, Map<Integer, BlockState>> blocks = new HashMap<>();
    private final Map<Long, ResourceLocation> loot = new HashMap<>();
    private final Map<Long, List<Spot>> spots = new HashMap<>();

    private IslandCanvas(Islands.Island isl) { this.isl = isl; }

    static IslandCanvas build(Islands.Island isl) {
        IslandCanvas c = new IslandCanvas(isl);
        CastleBuilder.build(c);
        VillageBuilder.build(c);
        Scenery.build(c);
        return c;
    }

    private static int pack(int x, int y, int z) { return ((y + 64) << 8) | ((x & 15) << 4) | (z & 15); }

    void set(int x, int y, int z, BlockState s) {
        blocks.computeIfAbsent(ChunkPos.asLong(x >> 4, z >> 4), k -> new HashMap<>()).put(pack(x, y, z), s);
    }

    BlockState get(int x, int y, int z) {
        Map<Integer, BlockState> m = blocks.get(ChunkPos.asLong(x >> 4, z >> 4));
        return m == null ? null : m.get(pack(x, y, z));
    }

    boolean has(int x, int y, int z) { return get(x, y, z) != null; }

    void chest(int x, int y, int z, BlockState state, ResourceLocation table) {
        set(x, y, z, state);
        loot.put(BlockPos.asLong(x, y, z), table);
    }

    void spot(int x, int y, int z, int kind, int variant) {
        spots.computeIfAbsent(ChunkPos.asLong(x >> 4, z >> 4), k -> new ArrayList<>()).add(new Spot(x, y, z, kind, variant));
    }

    /** Coloca en el chunk (cmx,cmz = esquina minima): terreno, estructuras, botin y habitantes. */
    void placeChunk(WorldGenLevel level, int cmx, int cmz) {
        BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos();
        for (int lx = 0; lx < 16; lx++) {
            for (int lz = 0; lz < 16; lz++) {
                Terrain.fillColumn(level, isl, cmx + lx, cmz + lz, p);
            }
        }
        long key = ChunkPos.asLong(cmx >> 4, cmz >> 4);
        Map<Integer, BlockState> m = blocks.get(key);
        if (m != null) {
            for (Map.Entry<Integer, BlockState> e : m.entrySet()) {
                int k = e.getKey();
                int y = (k >> 8) - 64;
                int lx = (k >> 4) & 15;
                int lz = k & 15;
                level.setBlock(p.set(cmx + lx, y, cmz + lz), e.getValue(), 2);
            }
        }
        RandomSource rnd = level.getRandom();
        for (Map.Entry<Long, ResourceLocation> e : loot.entrySet()) {
            long l = e.getKey();
            if ((BlockPos.getX(l) >> 4) != (cmx >> 4) || (BlockPos.getZ(l) >> 4) != (cmz >> 4)) continue;
            RandomizableContainerBlockEntity.setLootTable(level, rnd, BlockPos.of(l), e.getValue());
        }
        List<Spot> list = spots.get(key);
        if (list != null) {
            for (Spot s : list) Population.spawn(level, s, rnd);
        }
    }
}
