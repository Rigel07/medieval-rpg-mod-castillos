package com.castillosflotantes.world;

import com.castillosflotantes.entity.AldeanoEntity;
import com.castillosflotantes.entity.ModEntities;
import com.mojang.logging.LogUtils;
import net.minecraft.core.BlockPos;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraftforge.registries.ForgeRegistries;
import org.slf4j.Logger;

import java.util.ArrayList;
import java.util.List;

/** Habitantes de la isla: aldeanos medievales + criaturas pacificas de TODOS los mods instalados. */
final class Population {
    private static final Logger LOGGER = LogUtils.getLogger();
    private static volatile List<EntityType<?>> pool;

    /** Criaturas (categoria CREATURE) registradas por Minecraft y por cualquier mod. Los hostiles quedan fuera. */
    private static List<EntityType<?>> pool() {
        List<EntityType<?>> p = pool;
        if (p == null) {
            synchronized (Population.class) {
                p = pool;
                if (p == null) {
                    List<EntityType<?>> list = new ArrayList<>();
                    for (EntityType<?> t : ForgeRegistries.ENTITY_TYPES.getValues()) {
                        if (t.getCategory() == MobCategory.CREATURE && t.canSummon() && t != ModEntities.ALDEANO.get()) {
                            list.add(t);
                        }
                    }
                    pool = p = list;
                    LOGGER.info("[Castillos Flotantes] {} tipos de criaturas disponibles para poblar las islas", list.size());
                }
            }
        }
        return p;
    }

    private static Mob randomAnimal(WorldGenLevel level, RandomSource rnd) {
        List<EntityType<?>> list = pool();
        if (list.isEmpty()) return null;
        for (int i = 0; i < 8; i++) {
            EntityType<?> t = list.get(rnd.nextInt(list.size()));
            try {
                Entity e = t.create(level.getLevel());
                if (e instanceof Mob m && !(m instanceof Enemy)) return m;
            } catch (Throwable ignored) {
                // algun mod puede fallar al crearse fuera de su contexto: probamos otro
            }
        }
        return null;
    }

    static void spawn(WorldGenLevel level, IslandCanvas.Spot s, RandomSource rnd) {
        try {
            Mob mob;
            if (s.kind == IslandCanvas.VILLAGER) {
                AldeanoEntity a = ModEntities.ALDEANO.get().create(level.getLevel());
                if (a == null) return;
                a.setVariant(s.variant);
                mob = a;
            } else {
                mob = randomAnimal(level, rnd);
                if (mob == null) return;
            }
            BlockPos pos = new BlockPos(s.x, s.y, s.z);
            mob.moveTo(s.x + 0.5, s.y, s.z + 0.5, rnd.nextFloat() * 360.0F, 0.0F);
            mob.finalizeSpawn(level, level.getCurrentDifficultyAt(pos), MobSpawnType.STRUCTURE, null, null);
            mob.setPersistenceRequired();
            level.addFreshEntityWithPassengers(mob);
        } catch (Throwable t) {
            LOGGER.warn("[Castillos Flotantes] No se pudo crear un habitante: {}", t.toString());
        }
    }
}
