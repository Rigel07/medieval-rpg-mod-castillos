package com.castillosflotantes.world;

import com.mojang.serialization.Codec;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.FeaturePlaceContext;
import net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration;

/** Se ejecuta una vez por chunk; cada isla pinta solo la parte que cae dentro de ese chunk. */
public class FloatingIslandFeature extends Feature<NoneFeatureConfiguration> {

    public FloatingIslandFeature(Codec<NoneFeatureConfiguration> codec) {
        super(codec);
    }

    @Override
    public boolean place(FeaturePlaceContext<NoneFeatureConfiguration> ctx) {
        WorldGenLevel level = ctx.level();
        if (level.getLevel().dimension() != Level.OVERWORLD) return false;
        BlockPos o = ctx.origin();
        int cmx = (o.getX() >> 4) << 4;
        int cmz = (o.getZ() >> 4) << 4;
        boolean any = false;
        for (Islands.Island isl : Islands.near(level.getSeed(), cmx + 8, cmz + 8, Islands.RADIUS + 20)) {
            double dx = (cmx + 8) - isl.cx, dz = (cmz + 8) - isl.cz;
            if (Math.hypot(dx, dz) > Islands.RADIUS + 14) continue;
            Islands.canvas(isl).placeChunk(level, cmx, cmz);
            any = true;
        }
        return any;
    }
}
