package com.castillosflotantes.world;

import net.minecraft.core.Direction;
import net.minecraft.world.level.block.BedBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.CropBlock;
import net.minecraft.world.level.block.FarmBlock;
import net.minecraft.world.level.block.LanternBlock;
import net.minecraft.world.level.block.LayeredCauldronBlock;
import net.minecraft.world.level.block.RotatedPillarBlock;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BedPart;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;

import static com.castillosflotantes.world.Build.AIR_STATE;
import static com.castillosflotantes.world.Build.F;
import static com.castillosflotantes.world.Build.S;
import static net.minecraft.world.level.block.Blocks.*;

/** Pueblo medieval: calles, plaza con pozo, casas de entramado, herreria, panaderia, taberna, capilla, mercado, granjas y corrales. */
final class VillageBuilder {
    private enum Kind { HOME, SMITH, BAKERY, TAVERN, CHAPEL }

    static void build(IslandCanvas c) {
        Islands.Island isl = c.isl;
        int gv = isl.y0 + Islands.VILLAGE_DY;
        Build v = new Build(c, isl.vx, isl.vz, Rotation.NONE);

        streets(v, gv);
        Decor.well(v, 0, gv, 0);
        for (int sx : new int[]{-6, 6}) for (int sz : new int[]{-6, 6}) Decor.lamp(v, sx, gv, sz);
        for (int sx : new int[]{-16, 16}) { Decor.lamp(v, sx, gv, -3); Decor.lamp(v, sx, gv, 3); }

        // fila norte (puerta al sur) y fila sur (puerta al norte)
        house(c, isl, gv, -22, -11, Rotation.NONE, 3, 3, 4, Kind.HOME, 0);
        house(c, isl, gv, -10, -11, Rotation.NONE, 3, 3, 4, Kind.SMITH, 1);
        house(c, isl, gv, 10, -11, Rotation.NONE, 3, 3, 4, Kind.BAKERY, 2);
        house(c, isl, gv, 22, -11, Rotation.NONE, 3, 3, 4, Kind.HOME, 1);
        house(c, isl, gv, -22, 11, Rotation.CLOCKWISE_180, 3, 3, 4, Kind.HOME, 2);
        house(c, isl, gv, -10, 11, Rotation.CLOCKWISE_180, 3, 3, 4, Kind.HOME, 0);
        house(c, isl, gv, 16, 12, Rotation.CLOCKWISE_180, 5, 4, 4, Kind.TAVERN, 1);
        house(c, isl, gv, 0, -23, Rotation.NONE, 3, 5, 6, Kind.CHAPEL, 2);

        // mercado
        Decor.stall(v, -8, gv, 4, RED_WOOL, WHITE_WOOL);
        Decor.stall(v, 8, gv, 4, BLUE_WOOL, WHITE_WOOL);
        v.spawn(-8, gv + 1, 3, IslandCanvas.VILLAGER, 3);
        v.spawn(8, gv + 1, 3, IslandCanvas.VILLAGER, 0);

        farm(v, -22, -23, gv);
        farm(v, 22, -23, gv);
        pen(v, -22, 21, gv);
        pen(v, 22, 21, gv);
        pen(v, 0, 24, gv);

        // guardias y vecinos en la plaza
        v.spawn(-3, gv + 1, -3, IslandCanvas.VILLAGER, 4);
        v.spawn(3, gv + 1, 3, IslandCanvas.VILLAGER, 4);
        v.spawn(0, gv + 1, 7, IslandCanvas.VILLAGER, 4);
        v.spawn(-4, gv + 1, 2, IslandCanvas.VILLAGER, 0);
        for (int i = 0; i < 4; i++) v.spawn(-12 + i * 8, gv + 1, 0, IslandCanvas.ANIMAL, 0);
    }

    // ------------------------------------------------------------ calles
    private static void road(Build v, int u, int w, int gv) {
        int r = (int) Math.floorMod(Islands.hash(21, u, w), 100L);
        v.set(u, gv, w, r < 65 ? S(DIRT_PATH) : r < 80 ? S(COARSE_DIRT) : S(GRAVEL));
    }

    private static void streets(Build v, int gv) {
        for (int u = -30; u <= 30; u++) for (int w = -1; w <= 1; w++) road(v, u, w, gv);
        for (int w = -17; w <= 17; w++) for (int u = -1; u <= 1; u++) road(v, u, w, gv);
        for (int u = -5; u <= 5; u++) {
            for (int w = -5; w <= 5; w++) {
                if (u == 0 && w == 0) continue;
                int r = (int) Math.floorMod(Islands.hash(23, u, w), 3L);
                v.set(u, gv, w, r == 0 ? S(STONE_BRICKS) : r == 1 ? S(COBBLESTONE) : S(GRAVEL));
            }
        }
    }

    // ------------------------------------------------------------ casas
    private static void house(IslandCanvas c, Islands.Island isl, int gv, int du, int dw, Rotation rot,
                              int hw, int hd, int wh, Kind kind, int roofStyle) {
        Build b = new Build(c, isl.vx + du, isl.vz + dw, rot);
        BlockState plaster = S(WHITE_TERRACOTTA);
        BlockState floor = S(SPRUCE_PLANKS);
        BlockState glass = S(kind == Kind.CHAPEL ? PINK_STAINED_GLASS : LIGHT_BLUE_STAINED_GLASS);
        Block roofStairs = roofStyle == 0 ? BRICK_STAIRS : roofStyle == 1 ? SPRUCE_STAIRS : DARK_OAK_STAIRS;
        Block roofFull = roofStyle == 0 ? BRICKS : roofStyle == 1 ? SPRUCE_PLANKS : DARK_OAK_PLANKS;

        // suelo, cimientos y espacio interior
        for (int x = -hw; x <= hw; x++) {
            for (int z = -hd; z <= hd; z++) {
                boolean edge = Math.abs(x) == hw || Math.abs(z) == hd;
                b.set(x, gv, z, edge ? S(COBBLESTONE) : floor);
                for (int y = gv + 1; y <= gv + wh; y++) b.set(x, y, z, AIR_STATE);
            }
        }
        // paredes de entramado
        for (int x = -hw; x <= hw; x++) {
            for (int z = -hd; z <= hd; z++) {
                boolean xw = Math.abs(x) == hw, zw = Math.abs(z) == hd;
                if (!xw && !zw) continue;
                for (int y = gv + 1; y <= gv + wh; y++) {
                    BlockState s;
                    if (xw && zw) s = S(DARK_OAK_LOG);
                    else if (y == gv + wh) s = S(DARK_OAK_LOG).setValue(RotatedPillarBlock.AXIS, zw ? Direction.Axis.X : Direction.Axis.Z);
                    else s = plaster;
                    b.set(x, y, z, s);
                }
            }
        }
        // ventanas
        int winTop = kind == Kind.CHAPEL ? gv + 5 : gv + 3;
        int[] zs = hd >= 4 ? new int[]{-2, 2} : new int[]{0};
        for (int y = gv + 2; y <= winTop; y++) {
            for (int z : zs) { b.set(-hw, y, z, glass); b.set(hw, y, z, glass); }
            b.set(0, y, -hd, glass);
            if (hw >= 5) { b.set(-3, y, -hd, glass); b.set(3, y, -hd, glass); }
        }
        // puerta (arco abierto)
        b.set(0, gv + 1, hd, AIR_STATE);
        b.set(0, gv + 2, hd, AIR_STATE);
        // techo interior y extensiones de muro
        for (int x = -hw + 1; x <= hw - 1; x++)
            for (int z = -hd + 1; z <= hd - 1; z++) b.set(x, gv + wh + 1, z, floor);
        for (int z = -hd; z <= hd; z++) { b.set(-hw, gv + wh + 1, z, plaster); b.set(hw, gv + wh + 1, z, plaster); }
        // tejado a dos aguas (cumbrera en z)
        for (int k = 0; k <= hw; k++) {
            int y = gv + wh + 1 + k;
            int xl = -(hw + 1) + k, xr = (hw + 1) - k;
            for (int z = -(hd + 1); z <= hd + 1; z++) {
                b.set(xl, y, z, F(roofStairs, Direction.EAST));
                b.set(xr, y, z, F(roofStairs, Direction.WEST));
            }
            for (int x = -hw + k; x <= hw - k; x++) {
                b.set(x, y, -hd, plaster);
                b.set(x, y, hd, plaster);
            }
        }
        for (int z = -(hd + 1); z <= hd + 1; z++) b.set(0, gv + wh + 2 + hw, z, S(roofFull));
        // luz
        b.set(0, gv + wh, 0, S(LANTERN).setValue(LanternBlock.HANGING, true));
        furnish(b, gv, hw, hd, kind);
    }

    private static BlockState bed(Direction d, BedPart part) {
        return F(RED_BED, d).setValue(BedBlock.PART, part);
    }

    private static void furnish(Build b, int gv, int hw, int hd, Kind kind) {
        int y1 = gv + 1;
        switch (kind) {
            case HOME -> {
                b.set(-2, y1, -1, bed(Direction.NORTH, BedPart.FOOT));
                b.set(-2, y1, -2, bed(Direction.NORTH, BedPart.HEAD));
                b.set(2, y1, -2, S(SPRUCE_FENCE));
                b.set(2, y1 + 1, -2, S(SPRUCE_PRESSURE_PLATE));
                b.set(1, y1, -2, F(SPRUCE_STAIRS, Direction.WEST));
                b.set(-2, y1, 2, S(CRAFTING_TABLE));
                b.chest(2, y1, 1, Direction.WEST, "minecraft:chests/village/village_plains_house");
                for (int x = -1; x <= 1; x++) for (int z = -1; z <= 1; z++) b.set(x, y1, z, S(RED_CARPET));
                b.spawn(0, y1, 1, IslandCanvas.VILLAGER, 0);
            }
            case SMITH -> {
                b.set(-2, y1, -2, F(BLAST_FURNACE, Direction.SOUTH));
                b.set(0, y1, -2, F(ANVIL, Direction.EAST));
                b.set(2, y1, -2, S(SMITHING_TABLE));
                b.set(2, y1, 0, S(GRINDSTONE));
                b.set(-2, y1, 0, S(LAVA_CAULDRON));
                b.chest(-2, y1, 1, Direction.EAST, "minecraft:chests/village/village_weaponsmith");
                b.spawn(0, y1, 1, IslandCanvas.VILLAGER, 2);
            }
            case BAKERY -> {
                b.set(-2, y1, -2, F(SMOKER, Direction.SOUTH));
                b.set(-2, y1, -1, S(BARREL));
                b.set(-2, y1, 0, S(COMPOSTER));
                b.set(2, y1, -2, S(SPRUCE_PLANKS));
                b.set(2, y1 + 1, -2, S(CAKE));
                b.set(2, y1, 0, S(HAY_BLOCK));
                b.chest(2, y1, 1, Direction.WEST, "minecraft:chests/village/village_butcher");
                b.spawn(0, y1, 1, IslandCanvas.VILLAGER, 3);
            }
            case TAVERN -> {
                for (int x = -4; x <= 4; x++) {
                    b.set(x, y1, -3, (x & 1) == 0 ? S(BARREL) : S(SPRUCE_PLANKS));
                    if ((x & 1) != 0) b.set(x, y1 + 1, -3, S(SPRUCE_SLAB));
                }
                for (int tx : new int[]{-3, 0, 3}) {
                    b.set(tx, y1, 1, S(SPRUCE_FENCE));
                    b.set(tx, y1 + 1, 1, S(SPRUCE_PRESSURE_PLATE));
                    b.set(tx - 1, y1, 1, F(SPRUCE_STAIRS, Direction.WEST));
                    b.set(tx + 1, y1, 1, F(SPRUCE_STAIRS, Direction.EAST));
                }
                b.set(4, y1, 2, S(CAMPFIRE));
                for (int x : new int[]{-3, 3}) b.set(x, gv + 4, 0, S(LANTERN).setValue(LanternBlock.HANGING, true));
                b.chest(-4, y1, 3, Direction.EAST, "minecraft:chests/village/village_tannery");
                b.spawn(-2, y1, 2, IslandCanvas.VILLAGER, 0);
                b.spawn(2, y1, 2, IslandCanvas.VILLAGER, 3);
                b.spawn(0, y1, -1, IslandCanvas.VILLAGER, 1);
            }
            case CHAPEL -> {
                for (int z = -3; z <= 4; z++) b.set(0, y1, z, S(RED_CARPET));
                for (int z : new int[]{0, 2, 4}) {
                    b.set(-2, y1, z, F(SPRUCE_STAIRS, Direction.SOUTH));
                    b.set(2, y1, z, F(SPRUCE_STAIRS, Direction.SOUTH));
                }
                b.set(0, y1, -4, S(QUARTZ_BLOCK));
                b.set(0, y1 + 1, -4, S(WHITE_CANDLE).setValue(BlockStateProperties.LIT, true));
                b.set(0, y1, -3, F(LECTERN, Direction.SOUTH));
                b.set(-2, y1, -4, S(YELLOW_STAINED_GLASS));
                b.set(2, y1, -4, S(YELLOW_STAINED_GLASS));
                b.spawn(0, y1, -2, IslandCanvas.VILLAGER, 5);
            }
        }
    }

    // ------------------------------------------------------------ granjas y corrales
    private static void farm(Build v, int cu, int cw, int gv) {
        Block[] crops = {WHEAT, CARROTS, POTATOES};
        for (int u = -4; u <= 4; u++) {
            for (int w = -4; w <= 4; w++) {
                if (u == 0) { v.set(cu + u, gv, cw + w, S(WATER)); continue; }
                v.set(cu + u, gv, cw + w, S(FARMLAND).setValue(FarmBlock.MOISTURE, 7));
                v.set(cu + u, gv + 1, cw + w, crops[Math.floorMod(Math.abs(u) + (w > 0 ? 1 : 0), 3)]
                        .defaultBlockState().setValue(CropBlock.AGE, 7));
            }
        }
        v.set(cu + 2, gv + 1, cw, S(OAK_FENCE));
        v.set(cu + 2, gv + 2, cw, S(OAK_FENCE));
        v.set(cu + 2, gv + 3, cw, S(HAY_BLOCK));
        v.set(cu + 2, gv + 4, cw, F(CARVED_PUMPKIN, Direction.SOUTH));
        v.spawn(cu - 5, gv + 1, cw, IslandCanvas.VILLAGER, 1);
    }

    private static void pen(Build v, int cu, int cw, int gv) {
        for (int u = -4; u <= 4; u++) {
            for (int w = -4; w <= 4; w++) {
                if (Math.abs(u) != 4 && Math.abs(w) != 4) continue;
                if (u == 0 && w == 4) {
                    v.set(cu, gv + 1, cw + 4, F(SPRUCE_FENCE_GATE, Direction.SOUTH));
                } else {
                    v.set(cu + u, gv + 1, cw + w, S(SPRUCE_PLANKS));
                    v.set(cu + u, gv + 2, cw + w, S(SPRUCE_PLANKS));
                }
            }
        }
        v.set(cu - 3, gv + 1, cw - 3, S(HAY_BLOCK));
        v.set(cu + 3, gv + 1, cw - 3, S(WATER_CAULDRON).setValue(LayeredCauldronBlock.LEVEL, 3));
        for (int sx : new int[]{-2, 2}) for (int sz : new int[]{-1, 1}) v.spawn(cu + sx, gv + 1, cw + sz, IslandCanvas.ANIMAL, 0);
    }
}
