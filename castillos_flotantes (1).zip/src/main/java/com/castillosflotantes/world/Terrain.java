package com.castillosflotantes.world;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

import java.util.ArrayList;
import java.util.List;

/** Forma de la isla: relieve, lagos, parte inferior rocosa y capas de bloques. */
public final class Terrain {
    public static final class Lake {
        final int x, z, r, depth, ref;
        Lake(int x, int z, int r, int depth, int ref) { this.x = x; this.z = z; this.r = r; this.depth = depth; this.ref = ref; }
    }

    // ---------------------------------------------------------------- ruido
    private static double rand01(long seed, int xi, int zi) {
        long h = Islands.hash(seed, xi, zi);
        return ((h >>> 11) & 0x1FFFFFL) / (double) 0x200000L;
    }

    private static double smooth(double t) { return t * t * (3 - 2 * t); }
    private static double lerp(double a, double b, double t) { return a + (b - a) * t; }

    static double vnoise(long seed, double x, double z) {
        int x0 = (int) Math.floor(x), z0 = (int) Math.floor(z);
        double fx = smooth(x - x0), fz = smooth(z - z0);
        double a = rand01(seed, x0, z0), b = rand01(seed, x0 + 1, z0);
        double c = rand01(seed, x0, z0 + 1), d = rand01(seed, x0 + 1, z0 + 1);
        return lerp(lerp(a, b, fx), lerp(c, d, fx), fz);
    }

    static double fbm(long seed, double x, double z) {
        return 0.55 * vnoise(seed, x, z) + 0.30 * vnoise(seed + 1, x * 2.1, z * 2.1) + 0.15 * vnoise(seed + 2, x * 4.3, z * 4.3);
    }

    static double w(double d, double plateau, double blend) {
        if (d <= plateau) return 1.0;
        if (d >= plateau + blend) return 0.0;
        double s = (d - plateau) / blend;
        return 1.0 - s * s * (3 - 2 * s);
    }

    // ---------------------------------------------------------------- forma
    public static double edgeRadius(Islands.Island isl, double lx, double lz) {
        double a = Math.atan2(lz, lx);
        double n = vnoise(isl.seed + 7, Math.cos(a) * 2.2 + 10, Math.sin(a) * 2.2 + 10);
        return Islands.RADIUS * (0.88 + 0.12 * n);
    }

    public static Lake[] lakes(Islands.Island isl) {
        Lake[] cached = isl.lakes;
        if (cached != null) return cached;
        List<Lake> out = new ArrayList<>();
        for (int k = 0; k < 8 && out.size() < 3; k++) {
            long h = Islands.hash(isl.seed, 9000 + k, 77);
            double ang = Math.floorMod(h, 3600L) / 3600.0 * Math.PI * 2;
            double dist = 50 + Math.floorMod(h >>> 12, 55L);
            int r = 9 + (int) Math.floorMod(h >>> 24, 6L);
            int lx = (int) Math.round(Math.cos(ang) * dist), lz = (int) Math.round(Math.sin(ang) * dist);
            if (Math.max(Math.abs(lx), Math.abs(lz)) < Islands.CASTLE_HALF + 10 + r + 6) continue;
            int wx = isl.cx + lx, wz = isl.cz + lz;
            if (Math.hypot(wx - isl.vx, wz - isl.vz) < Islands.VILLAGE_R + 10 + r + 6) continue;
            if (dist + r + 8 > Islands.RADIUS * 0.88) continue;
            boolean overlap = false;
            for (Lake o : out) if (Math.hypot(o.x - wx, o.z - wz) < o.r + r + 10) overlap = true;
            if (overlap) continue;
            int ref = (int) Math.round(isl.y0 + (fbm(isl.seed, wx * 0.018, wz * 0.018) - 0.5) * 16.0);
            out.add(new Lake(wx, wz, r, 4, ref));
        }
        Lake[] arr = out.toArray(new Lake[0]);
        isl.lakes = arr;
        return arr;
    }

    public static Lake lakeAt(Islands.Island isl, int x, int z) {
        for (Lake l : lakes(isl)) if (Math.hypot(x - l.x, z - l.z) < l.r) return l;
        return null;
    }

    /** true si (x,z) esta dentro de un lago o a menos de 'margin' bloques de su orilla. */
    public static boolean lakeNear(Islands.Island isl, int x, int z, int margin) {
        for (Lake l : lakes(isl)) if (Math.hypot(x - l.x, z - l.z) < l.r + 6 + margin) return true;
        return false;
    }

    public static int groundH(Islands.Island isl, int x, int z) {
        double lx = x - isl.cx, lz = z - isl.cz;
        double base = isl.y0 + (fbm(isl.seed, x * 0.018, z * 0.018) - 0.5) * 16.0;
        double r = Math.sqrt(lx * lx + lz * lz);
        double t = Math.min(1.0, r / edgeRadius(isl, lx, lz));
        if (t > 0.88) base -= 7.0 * (t - 0.88) / 0.12;
        double wc = w(Math.max(Math.abs(lx), Math.abs(lz)), Islands.CASTLE_HALF, 10);
        base = base * (1 - wc) + (isl.y0 + Islands.CASTLE_DY) * wc;
        double wv = w(Math.hypot(x - isl.vx, z - isl.vz), Islands.VILLAGE_R, 10);
        base = base * (1 - wv) + (isl.y0 + Islands.VILLAGE_DY) * wv;
        for (Lake l : lakes(isl)) {
            double d = Math.hypot(x - l.x, z - l.z);
            if (d < l.r + 6) {
                double wl = w(d, l.r, 6);
                base = base * (1 - wl) + l.ref * wl;
                if (d < l.r) {
                    double q = d / l.r;
                    base -= l.depth * (1 - q * q);
                }
            }
        }
        return (int) Math.round(base);
    }

    public static int depth(Islands.Island isl, int x, int z, double t) {
        double shape = Math.pow(Math.max(0.0, 1.0 - t * t), 1.15);
        double n = vnoise(isl.seed + 11, x * 0.05, z * 0.05);
        double spikes = vnoise(isl.seed + 13, x * 0.22, z * 0.22);
        int d = (int) (Islands.MAX_DEPTH * shape * (0.75 + 0.5 * n) + spikes * 7);
        return Math.max(d, 4);
    }

    // ---------------------------------------------------------------- relleno
    private static BlockState pick(Islands.Island isl, int x, int y, int z, int top, int bottom, boolean bowl) {
        long h = Islands.hash(isl.seed + 31, x * 31L + y, z);
        if (y == top) {
            if (bowl) return Math.floorMod(h, 3L) == 0 ? Blocks.GRAVEL.defaultBlockState() : Blocks.SAND.defaultBlockState();
            return Blocks.GRASS_BLOCK.defaultBlockState();
        }
        if (y >= top - 3) {
            if (bowl) return Blocks.SAND.defaultBlockState();
            return Math.floorMod(h, 20L) == 0 ? Blocks.COARSE_DIRT.defaultBlockState() : Blocks.DIRT.defaultBlockState();
        }
        int r = (int) Math.floorMod(h, 1000L);
        if (r < 10) return Blocks.COAL_ORE.defaultBlockState();
        if (r < 17) return Blocks.IRON_ORE.defaultBlockState();
        if (r < 23) return Blocks.COPPER_ORE.defaultBlockState();
        if (r < 26) return Blocks.GOLD_ORE.defaultBlockState();
        if (r < 30) return Blocks.REDSTONE_ORE.defaultBlockState();
        if (r < 32) return Blocks.LAPIS_ORE.defaultBlockState();
        if (r < 33 && y < top - 15) return Blocks.DIAMOND_ORE.defaultBlockState();
        int s = (int) Math.floorMod(h >>> 10, 100L);
        if (y < bottom + 5) return s < 50 ? Blocks.COBBLED_DEEPSLATE.defaultBlockState() : Blocks.DEEPSLATE.defaultBlockState();
        if (s < 65) return Blocks.STONE.defaultBlockState();
        if (s < 77) return Blocks.ANDESITE.defaultBlockState();
        if (s < 85) return Blocks.COBBLESTONE.defaultBlockState();
        if (s < 92) return Blocks.GRANITE.defaultBlockState();
        return Blocks.TUFF.defaultBlockState();
    }

    /** Rellena una columna de la isla (superficie + parte inferior rocosa + agua de lagos). */
    static void fillColumn(WorldGenLevel level, Islands.Island isl, int x, int z, BlockPos.MutableBlockPos p) {
        double lx = x - isl.cx, lz = z - isl.cz;
        double r = Math.sqrt(lx * lx + lz * lz);
        double reff = edgeRadius(isl, lx, lz);
        if (r > reff) return;
        int top = groundH(isl, x, z);
        int bottom = top - depth(isl, x, z, r / reff);
        Lake lake = lakeAt(isl, x, z);
        boolean bowl = lake != null;
        for (int y = bottom; y <= top; y++) {
            level.setBlock(p.set(x, y, z), pick(isl, x, y, z, top, bottom, bowl), 2);
        }
        if (bowl) {
            BlockState water = Blocks.WATER.defaultBlockState();
            for (int y = top + 1; y <= lake.ref - 1; y++) level.setBlock(p.set(x, y, z), water, 2);
        }
    }
}
