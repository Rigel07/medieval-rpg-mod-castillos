package com.castillosflotantes.entity;

import com.castillosflotantes.CastillosFlotantesMod;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, CastillosFlotantesMod.MOD_ID);

    public static final RegistryObject<EntityType<AldeanoEntity>> ALDEANO =
            ENTITIES.register("aldeano", () ->
                    EntityType.Builder.<AldeanoEntity>of(AldeanoEntity::new, MobCategory.MISC)
                            .sized(0.55f, 1.25f)
                            .clientTrackingRange(10)
                            .build(new ResourceLocation(CastillosFlotantesMod.MOD_ID, "aldeano").toString()));
}
