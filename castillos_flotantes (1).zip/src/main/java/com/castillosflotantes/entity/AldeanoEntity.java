package com.castillosflotantes.entity;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.AvoidEntityGoal;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.MoveTowardsRestrictionGoal;
import net.minecraft.world.entity.ai.goal.PanicGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;
import org.jetbrains.annotations.Nullable;

/**
 * Aldeano medieval: pequeno y adorable. 6 oficios (campesino, granjero, herrero, panadero, guardia, noble).
 * Dale una esmeralda y te da algo a cambio (6 tratos al dia). Los guardias defienden con espada.
 */
public class AldeanoEntity extends PathfinderMob {
    public static final int VARIANTS = 6;
    public static final String[] NAMES = {"campesino", "granjero", "herrero", "panadero", "guardia", "noble"};

    private static final EntityDataAccessor<Integer> VARIANT =
            SynchedEntityData.defineId(AldeanoEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Boolean> WAVING =
            SynchedEntityData.defineId(AldeanoEntity.class, EntityDataSerializers.BOOLEAN);

    private int stock = 6;
    private long stockDay = -1L;
    private int wavingTicks = 0;

    public AldeanoEntity(EntityType<? extends AldeanoEntity> type, Level level) {
        super(type, level);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 20.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.25D)
                .add(Attributes.ATTACK_DAMAGE, 4.0D)
                .add(Attributes.FOLLOW_RANGE, 24.0D);
    }

    // ------------------------------------------------------------ IA
    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new PanicGoal(this, 1.4D) {
            @Override
            public boolean canUse() { return !isKnight() && super.canUse(); }
        });
        this.goalSelector.addGoal(2, new AvoidEntityGoal<Monster>(this, Monster.class, 10.0F, 1.0D, 1.3D) {
            @Override
            public boolean canUse() { return !isKnight() && super.canUse(); }
        });
        this.goalSelector.addGoal(3, new MeleeAttackGoal(this, 1.15D, true) {
            @Override
            public boolean canUse() { return isKnight() && super.canUse(); }
        });
        this.goalSelector.addGoal(4, new MoveTowardsRestrictionGoal(this, 0.9D));
        this.goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.7D));
        this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 8.0F));
        this.goalSelector.addGoal(7, new RandomLookAroundGoal(this));
        this.targetSelector.addGoal(1, new HurtByTargetGoal(this) {
            @Override
            public boolean canUse() { return isKnight() && super.canUse(); }
        });
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<Monster>(this, Monster.class, true) {
            @Override
            public boolean canUse() { return isKnight() && super.canUse(); }
        });
    }

    // ------------------------------------------------------------ datos
    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(VARIANT, 0);
        this.entityData.define(WAVING, false);
    }

    public int getVariant() { return Mth.clamp(this.entityData.get(VARIANT), 0, VARIANTS - 1); }
    public void setVariant(int v) { this.entityData.set(VARIANT, Mth.clamp(v, 0, VARIANTS - 1)); }
    public boolean isWaving() { return this.entityData.get(WAVING); }
    public boolean isKnight() { return getVariant() == 4; }
    public boolean hasBrim() { return getVariant() == 1; }

    public void setHome(BlockPos pos, int radius) {
        this.restrictTo(pos, radius);
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("Variant", getVariant());
        if (hasRestriction()) {
            BlockPos c = getRestrictCenter();
            tag.putInt("HomeX", c.getX());
            tag.putInt("HomeY", c.getY());
            tag.putInt("HomeZ", c.getZ());
        }
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        setVariant(tag.getInt("Variant"));
        if (tag.contains("HomeX")) {
            setHome(new BlockPos(tag.getInt("HomeX"), tag.getInt("HomeY"), tag.getInt("HomeZ")), 32);
        }
    }

    @Nullable
    @Override
    public SpawnGroupData finalizeSpawn(ServerLevelAccessor level, DifficultyInstance difficulty,
                                        MobSpawnType reason, @Nullable SpawnGroupData spawnData,
                                        @Nullable CompoundTag dataTag) {
        if (reason != MobSpawnType.STRUCTURE) setVariant(level.getRandom().nextInt(VARIANTS));
        setHome(blockPosition(), 32);
        this.setPersistenceRequired();
        if (isKnight()) {
            setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.IRON_SWORD));
            setItemSlot(EquipmentSlot.OFFHAND, new ItemStack(Items.SHIELD));
            setDropChance(EquipmentSlot.MAINHAND, 0.05F);
            setDropChance(EquipmentSlot.OFFHAND, 0.05F);
        }
        return super.finalizeSpawn(level, difficulty, reason, spawnData, dataTag);
    }

    @Override
    public boolean removeWhenFarAway(double distance) { return false; }

    @Override
    protected Component getTypeName() {
        return Component.translatable("entity.castillos_flotantes.aldeano." + NAMES[getVariant()]);
    }

    // ------------------------------------------------------------ comportamiento
    @Override
    public void aiStep() {
        super.aiStep();
        if (this.level().isClientSide) return;
        if (this.wavingTicks > 0) {
            this.wavingTicks--;
            if (this.wavingTicks == 0) this.entityData.set(WAVING, false);
        } else if (this.random.nextInt(120) == 0) {
            Player p = this.level().getNearestPlayer(this, 6.0D);
            if (p != null) {
                this.wavingTicks = 40;
                this.entityData.set(WAVING, true);
            }
        }
    }

    private void refreshStock() {
        long day = this.level().getDayTime() / 24000L;
        if (day != this.stockDay) {
            this.stockDay = day;
            this.stock = 6;
        }
    }

    private ItemStack rollReward() {
        int r = this.random.nextInt(100);
        return switch (getVariant()) {
            case 0 -> r < 40 ? new ItemStack(Items.BREAD, 3) : r < 75 ? new ItemStack(Items.BAKED_POTATO, 3) : new ItemStack(Items.CARROT, 4);
            case 1 -> r < 35 ? new ItemStack(Items.WHEAT, 6) : r < 65 ? new ItemStack(Items.PUMPKIN_PIE, 1)
                    : r < 90 ? new ItemStack(Items.APPLE, 3) : new ItemStack(Items.GOLDEN_CARROT, 2);
            case 2 -> r < 40 ? new ItemStack(Items.IRON_INGOT, 2) : r < 75 ? new ItemStack(Items.COAL, 5)
                    : r < 95 ? new ItemStack(Items.IRON_NUGGET, 9) : new ItemStack(Items.IRON_PICKAXE);
            case 3 -> r < 35 ? new ItemStack(Items.BREAD, 4) : r < 65 ? new ItemStack(Items.COOKIE, 8)
                    : r < 90 ? new ItemStack(Items.PUMPKIN_PIE, 2) : new ItemStack(Items.CAKE);
            case 4 -> r < 40 ? new ItemStack(Items.ARROW, 12) : r < 70 ? new ItemStack(Items.COOKED_BEEF, 3)
                    : r < 90 ? new ItemStack(Items.SHIELD) : new ItemStack(Items.IRON_SWORD);
            default -> r < 45 ? new ItemStack(Items.GOLD_INGOT, 2) : r < 80 ? new ItemStack(Items.GOLD_NUGGET, 9)
                    : r < 95 ? new ItemStack(Items.GOLDEN_APPLE) : new ItemStack(Items.NAME_TAG);
        };
    }

    @Override
    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        if (hand != InteractionHand.MAIN_HAND) return InteractionResult.PASS;
        boolean client = this.level().isClientSide;
        ItemStack held = player.getItemInHand(hand);

        if (held.is(Items.EMERALD)) {
            if (!client) {
                refreshStock();
                if (this.stock <= 0) {
                    player.displayClientMessage(Component.translatable("message.castillos_flotantes.trade_none"), true);
                    this.playSound(SoundEvents.VILLAGER_NO, 1.0F, 1.2F);
                } else {
                    if (!player.getAbilities().instabuild) held.shrink(1);
                    this.stock--;
                    ItemStack reward = rollReward();
                    if (!player.getInventory().add(reward)) player.drop(reward, false);
                    player.displayClientMessage(Component.translatable("message.castillos_flotantes.trade_ok"), true);
                    this.playSound(SoundEvents.VILLAGER_YES, 1.0F, 1.2F);
                    if (this.level() instanceof ServerLevel sl) {
                        sl.sendParticles(ParticleTypes.HAPPY_VILLAGER, getX(), getY() + 1.2, getZ(), 6, 0.3, 0.3, 0.3, 0.02);
                    }
                }
            }
            return InteractionResult.sidedSuccess(client);
        }

        if (!client) {
            int i = this.random.nextInt(3);
            player.displayClientMessage(Component.translatable(
                    "message.castillos_flotantes.greet." + getVariant() + "." + i), true);
            this.wavingTicks = 40;
            this.entityData.set(WAVING, true);
            this.playSound(SoundEvents.VILLAGER_CELEBRATE, 0.8F, 1.3F);
        }
        return InteractionResult.sidedSuccess(client);
    }

    // ------------------------------------------------------------ sonidos
    @Nullable
    @Override
    protected SoundEvent getAmbientSound() { return SoundEvents.VILLAGER_AMBIENT; }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) { return SoundEvents.VILLAGER_HURT; }

    @Override
    protected SoundEvent getDeathSound() { return SoundEvents.VILLAGER_DEATH; }
}
