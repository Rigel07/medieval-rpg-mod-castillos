package com.castillosflotantes.item;

import com.castillosflotantes.CastillosFlotantesMod;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

public class ModCreativeTabs {
    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, CastillosFlotantesMod.MOD_ID);

    public static final RegistryObject<CreativeModeTab> MAIN = TABS.register("main",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup." + CastillosFlotantesMod.MOD_ID))
                    .icon(() -> new ItemStack(ModItems.ALDEANO_SPAWN_EGG.get()))
                    .displayItems((params, output) -> output.accept(ModItems.ALDEANO_SPAWN_EGG.get()))
                    .build());
}
