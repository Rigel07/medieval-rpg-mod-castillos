package com.castillosflotantes.item;

import com.castillosflotantes.CastillosFlotantesMod;
import com.castillosflotantes.entity.ModEntities;
import net.minecraft.world.item.Item;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, CastillosFlotantesMod.MOD_ID);

    public static final RegistryObject<Item> ALDEANO_SPAWN_EGG = ITEMS.register("aldeano_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.ALDEANO, 0x9C6B3C, 0xC0392B, new Item.Properties()));
}
